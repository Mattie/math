theorem preflight : True := True.intro
