theorem preflight : 1 = 1 := rfl
