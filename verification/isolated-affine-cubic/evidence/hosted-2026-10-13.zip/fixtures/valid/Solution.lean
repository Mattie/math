import Lean
#eval do
  let result ← IO.Process.output { cmd := "/home/runner/work/_temp/isolated-irrationality/tools/lean-4.34.1-linux/bin/preflight-boundary-probe", args := #["/home/runner/work/_temp/isolated-irrationality/valid/.lake/allowed.txt", "/home/runner/work/_temp/isolated-irrationality/valid/Challenge.lean", "/home/runner/work/_temp/isolated-irrationality/valid/config.json", "/home/runner/work/_temp/isolated-irrationality/tools/lean-4.34.1-linux/protected-marker", "/home/runner/work/_temp/isolated-irrationality/outside-marker", "/home/runner/work/_temp/isolated-irrationality/valid/.lake/escape/outside-marker"] }
  if result.exitCode != 0 then throw (IO.userError result.stderr)
  IO.FS.writeFile ".lake/boundary.json" result.stdout
theorem preflight : True := True.intro
