# PiTwoCaseBridge, November 26, 2026

The archive contains the Lean overlay and pinned dependency information
accompanying *The irrationality exponent of pi through a two-case
determinant argument*.

Start with [Main.lean](formalizations/PiTwoCaseBridge/PiTwoCaseBridge/Main.lean)
or the [build instructions](formalizations/PiTwoCaseBridge/README.md).
The build uses the inherited OpenAI PiExponent libraries and Mathlib on
LEAN_PATH. The [manifest](manifest.json) gives the upstream revisions
and SHA-256 hashes of the 30 recorded inputs. The [verification record](VERIFY.md)
identifies the replay root, checker results, and export command.
